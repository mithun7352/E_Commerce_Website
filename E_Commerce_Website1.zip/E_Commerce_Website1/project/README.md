# Springboot_Projects

Project name : E-Commerce Website

Team Member are :  

Veer Pratap Singh
Vishal Kumar
Rajababu Kumar Singh
Aagman Mehto
Mohit Patel


Use Tools and software:

Tools are:                                Used software are:

1. Java 8                               1. VS Code (IDE and code editor)
2. Spring Boot                          2. Chrome browser
3. HTML                                 3. MY SQL Workbench
4. CSS                             
5. JavaScript
6. BootStrap
7. MYSQL


Database and connection details are in src/main/resource/application.properties.

